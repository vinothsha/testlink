UPDATE `rights` SET `rights` = 'tp_execute,tp_create_build,tp_metrics,tp_planning,tp_assign_rights,mgt_view_tc,mgt_modify_tc,mgt_view_key,mgt_modify_key,mgt_view_req,mgt_modify_req,mgt_modify_product,mgt_users' WHERE `id` = 8 LIMIT 1;
UPDATE `rights` SET `rights` = 'tp_execute,tp_create_build,tp_metrics,tp_planning,tp_assign_rights,mgt_view_tc,mgt_modify_tc,mgt_view_key,mgt_modify_key,mgt_view_req,mgt_modify_req'  WHERE `id` = 9 LIMIT 1;
UPDATE `rights` SET `rights` = 'tp_execute,tp_metrics,tp_create_build,mgt_view_tc,mgt_modify_tc,mgt_view_key,mgt_view_req' WHERE `id` = 6 LIMIT 1;
UPDATE `rights` SET `rights` = 'tp_execute,tp_metrics,mgt_view_tc,mgt_view_key,mgt_view_req' WHERE `id` = 7 LIMIT 1;
UPDATE `rights` SET `rights` = 'tp_metrics,mgt_view_tc,mgt_view_key,mgt_view_req' WHERE `id` = 5 LIMIT 1;
UPDATE `rights` SET `rights` = 'tp_metrics,mgt_view_tc,mgt_modify_tc,mgt_view_key,mgt_modify_req,mgt_view_req' WHERE `id` = 4 LIMIT 1;