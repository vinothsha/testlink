/* 
$Revision: 1.3 $
$Date: 2007/10/21 15:59:49 $
$Author: franciscom $
$Name: testlink_1_9 $
*/
INSERT INTO db_version VALUES('DB 1.1', now());